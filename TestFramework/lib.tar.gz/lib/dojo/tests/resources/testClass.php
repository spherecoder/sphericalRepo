<?php
class testClass {

	function myecho ($somestring) {
		return "<P>" . $somestring . "</P>";
	}

	function contentB () {
		return "<P>Content B</P>";
	}

	function contentC () {
		return "<P>Content C</P>";
	}

	function add($x,$y) {
		return $x + $y;
	}
}
?>
